#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "devices/shutdown.h"
#include "process.h"
#include "threads/vaddr.h"

#include "threads/synch.h"	// project 2


static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//	printf("syscall num : %d\n", *(uint32_t *)(f->esp));

	switch( *(uint32_t *)(f->esp) ){
		/////////////// project 1 ///////////////
		/* HALT, EXIT, EXEC, WAIT, READ, WRITE */
		/////////////////////////////////////////

		/////////////// project 2 ///////////////
		/* CREATE, REMOVE, OPEN, CLOSE, FILESIZE, READ, WRITE, SEEK, TELL */
		/////////////////////////////////////////

		// use f->eax when return value exists
		case SYS_HALT : halt(); break;
		case SYS_EXIT : 
						if( (uint32_t *)(f->esp +4) >= PHYS_BASE ) exit(-1);
						exit((int)*(uint32_t *)(f->esp +4)); break;
		case SYS_EXEC : 
						if( (uint32_t *)(f->esp +4) >= PHYS_BASE ) exit(-1);
						f->eax = exec((char *)*(uint32_t *)(f->esp +4)); break;
		case SYS_WAIT : f->eax = wait((pid_t)*(uint32_t *)(f->esp +4)); break;


		case SYS_CREATE : // project 2
						if( (unsigned int *)(f->esp +8) >= PHYS_BASE ) exit(-1);	// address check for 2 args
						f->eax = create((const char *)*(unsigned int *)(f->esp +4), (unsigned)*(unsigned int *)(f->esp +8));
						break;
		case SYS_REMOVE : // project 2
						if( (unsigned int *)(f->esp +4) >= PHYS_BASE ) exit(-1);	// address check for 1 arg
						f->eax = remove((const char*)*(unsigned int *)(f->esp +4));
						break;
		case SYS_OPEN : // project 2
						if( (unsigned int *)(f->esp +4) >= PHYS_BASE ) exit(-1);    // address check for 1 arg
						f->eax = open((const char*)*(unsigned int *)(f->esp +4));
						break;
		case SYS_FILESIZE : // project 2
						if( (unsigned int *)(f->esp +4) >= PHYS_BASE ) exit(-1);    // address check for 1 arg
						f->eax = filesize((int)*(unsigned int *)(f->esp +4));
						break;
		case SYS_READ :  // project 1 & project 2
						if( (unsigned int *)(f->esp +12) >= PHYS_BASE ) exit(-1);
						f->eax = read((int)*(uint32_t *)(f->esp +4),
								(void *)*(uint32_t *)(f->esp +8),
								(unsigned)*(uint32_t *)(f->esp +12));
						break;
		case SYS_WRITE : // project 1 & project 2
//						hex_dump (f->esp, f->esp, 100, 1);
						if( (unsigned int *)(f->esp +12) >= PHYS_BASE ) exit(-1);
						f->eax = write((int)*(uint32_t *)(f->esp +4),
								(void *)*(uint32_t *)(f->esp +8),
								(unsigned)*(uint32_t *)(f->esp +12));
						break;
		case SYS_SEEK : // project 2
						if( (unsigned int *)(f->esp +8) >= PHYS_BASE ) exit(-1);    // address check for 2 args
						seek((int)*(unsigned int *)(f->esp +4), (unsigned)*(unsigned int *)(f->esp +8));
						break;
		case SYS_TELL : // project 2
						if( (unsigned int *)(f->esp +4) >= PHYS_BASE ) exit(-1);    // address check for 1 arg
						f->eax = tell((int)*(unsigned int *)(f->esp +4));
						break;
		case SYS_CLOSE : // project 2
						if( (unsigned int *)(f->esp +4) >= PHYS_BASE ) exit(-1);    // address check for 1 arg
						close((int)*(unsigned int *)(f->esp +4));
						break;


		case SYS_MMAP : break;
		case SYS_MUNMAP : break;


		case SYS_CHDIR : break;
		case SYS_MKDIR : break;
		case SYS_READDIR : break;
		case SYS_ISDIR : break;
		case SYS_INUMBER : break;
		case SYS_FIBO : f->eax = fibonacci((int)*(uint32_t *)(f->esp +4));
						break;
		case SYS_SUM : f->eax = sum_four_int((int)*(uint32_t *)(f->esp +4),
							   (int)*(uint32_t *)(f->esp +8), (int)*(uint32_t *)(f->esp +12),
							   (int)*(uint32_t *)(f->esp +16));
					   break;
	};	

//  printf ("system call!\n");
//  thread_exit ();
}

/* project 2 */
bool create (const char *file, unsigned initial_size)
{
	if(file)
		return filesys_create(file, initial_size);
	else
		exit(-1);
}

bool remove(const char *file)
{
	if(file)
		return filesys_remove(file);
	else
		exit(-1);
}

int open(const char *file)
{
	int i;
	if(!file)
		return -1;	// exit(-1)?

	lock_acquire(&open_lock);		// lock
	struct file *fp = filesys_open(file);
	lock_release(&open_lock);		// lock
	if(fp){
		for(i=2; i<128; i++){ // 0~1 is for console
			if(thread_current()->fd[i] == NULL){
				thread_current()->fd[i] = fp;
				if(!strcmp(file, thread_current()->name))
					file_deny_write(fp);					// when to change deny->allow?
//				lock_release(&prj2_lock);       // lock
				return i;
			}
		}
	}
//	lock_release(&prj2_lock);       // lock
	return -1;
}

int filesize(int fd)
{
	struct file *file = thread_current()->fd[fd];
	if(file)
		return file_length(file);
	else
		exit(-1);
}

void seek(int fd, unsigned position)
{
	struct file *file = thread_current()->fd[fd];
	if(file)
		file_seek(file, position);
	else
		exit(-1);
}

unsigned tell(int fd)
{
	struct file *file = thread_current()->fd[fd];
	if(file)
		return file_tell(file);
	else
		exit(-1);
}

void close(int fd)
{
	struct file *file = thread_current()->fd[fd];
	if(file){
		thread_current()->fd[fd] = NULL;
		file_close(file);
	}
	else
		exit(-1);
}



/* project 1 */
void halt(void)
{
	shutdown_power_off();
}

void exit(int status)
{
	int i;
	struct thread *current = thread_current();
	printf("%s: exit(%d)\n", current->name, status);

	for(i=2; i<128; i++){		// project 2
		if(current->fd[i])
			close(i);
	}

	thread_current()->exit_status = status;
	thread_exit();
}

pid_t exec(const char *cmd_line)
{
//	printf("cmd_line : %s\n\n", cmd_line);
	pid_t id = process_execute(cmd_line);
	if(id == -1) return -1;
	return id;
}

int wait(pid_t pid)
{
//	struct thread *parent = thread_current();
//	struct thread *ct;
//	struct list_elem *children = list_begin(&( parent->child_list ));
//	while(children != list_end(&( parent->child_list ))){
//		ct = list_entry(children, struct thread, child_elem);
//		if(ct->tid == pid && ct->flag){
//			printf("pid is %d\n", pid);
//			return pid;
//		}
//	}
	return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size)		// project 1 & project 2
{
	int result, exits=0;
	struct file *file; // project 2
	uint32_t  i;
	if(fd < 0 || fd == 1) return -1;	// project 2

	lock_acquire(&prj2_lock);       // lock
	if(fd==0){
		for(i=0;i<size;i++){
			*(uint8_t *)(buffer +i) = input_getc();
		}
//		lock_release(&prj2_lock);       // lock
		result = i;
//		if(i==size) return size;
//		else return -1;
	}
	else{
		file = thread_current()->fd[fd];	// project 2
		if(file){
			if(buffer >= PHYS_BASE){ lock_release(&prj2_lock); exit(-1); }	// lock
//			lock_acquire(&prj2_lock);		// lock
			
			result = file_read(file, buffer, size);	// project 2
			
//			lock_release(&prj2_lock);		// lock
		}
		else{
//			lock_release(&prj2_lock);       // lock
//			exit(-1);
			exits=1;
		}
	}
	lock_release(&prj2_lock);       // lock
	if(exits) exit(-1);
	return result;
}

int write(int fd, const void *buffer, unsigned size)		// project 1 & project 2
{
	int after;
	struct file *file; // project 2
	if(fd < 0 || fd == 0) return -1;	// project 2

	lock_acquire(&prj2_lock);       // lock
	if(fd==1){
		putbuf(buffer, size);
		lock_release(&prj2_lock);       // lock
		return size;
	}
	else{
		file = thread_current()->fd[fd];	// project 2
		if(file){
			if(buffer >= PHYS_BASE) { lock_release(&prj2_lock); exit -1; } // lock
//			lock_acquire(&prj2_lock);		// lock
			after = file_write(file, buffer, size);	// project 2
			lock_release(&prj2_lock);		// lock
			return after;
		}
		else{
			lock_release(&prj2_lock);       // lock
			exit(-1);
		}
	}
}

int fibonacci (int n)
{
	int i, x=1, y=1, s=0;
	if(n<=0) return -1;
	else if(n==1 || n==2) return 1;
	else{
		for(i=2;i<n;i++){
			s = x+y;
			x = y;
			y = s;
		}
		return s;
	}
}

int sum_four_int (int a, int b, int c, int d)
{
	return a+b+c+d;
}
