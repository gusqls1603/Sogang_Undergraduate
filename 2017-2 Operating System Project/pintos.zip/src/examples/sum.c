#include <stdio.h>
#include <syscall.h>

int main(int argc, char *argv[])
{

	int a, b, c, d;
	a = argv[1][0] - 48;
	b = argv[2][0] - 48;
	c = argv[3][0] - 48;
	d = argv[4][0] - 48;
	
	printf("%d %d\n", fibonacci(a), sum_four_int(a, b, c, d));
	return 0;
}

/*
int fibonacci(int n)
{
	int i, a=1, b=1, s=0;

	if(n<=0) return -1;
	switch(n){
	case 1 : s = 1; break;
	case 2 : s = 1; break;
	default : 
			 for(i=2;i<n;i++){
				 s = a + b;
				 a = b;
				 b = s;
			 }
			 break;
	}
	return s;
}

int sum_four_int(int a, int b, int c, int d)
{
	return a+b+c+d;
}*/
